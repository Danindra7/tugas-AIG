#include<stdio.h>
#include<conio.h>
#include<iostream>
#include<math.h>
#include<string.h>

float waktu_tertinggi(float kecepatan, float radius, float gravitasi){
	// Mencari waktu yang diperlukan peluru untuk mencapai titik tertinggi
	// tmaks = V0 * sin(rad) / g
	float tmaks = 0;
	tmaks = kecepatan * sin(radius) / gravitasi;

	return tmaks;
}

float titik_tertinggi(float kecepatan, float radius, float gravitasi){
	// Mencari waktu yang diperlukan peluru untuk mencapai tanah (gerak jatuh bebas)
	// Awal-awal kita cari tinggi maksimum yang bisa dicapai oleh peluru
	// ymaks = pow(V0,2)*pow(sin(rad),2)/2g
	float ymaks = 0;
	ymaks = pow(kecepatan,2) * pow(sin(radius),2)/(2*gravitasi);

	return ymaks;

}

float total_Height(float height_awal,float height_akhir){
	float totalHeight = height_awal + height_akhir;

	return totalHeight;
}

float waktu_jatuh(float total_height,float gravitasi){
	// Hitung waktu tempuh ke lantai dengan rumus ketinggian
	// y = Vy0t - 1/2g * pow(t) -> kecepatan saat di titik tertinggi  = 0
	// y = 0 - 1/2g * pow(t)
	// y = - 1/2g * pow(t)
	// pow(t) = 2*y / g
	// t = sqrt(2*y / g)
	float tAkhir = sqrt(2*total_height/gravitasi);
	return tAkhir;
}

float waktu_total(float waktu_tertinggi, float waktu_akhir){
	// Hitung total waktu dengan menjumlahkan tmaks dan takhir
	// total tinggi = height + ymaks
	float tTotal = waktu_tertinggi + waktu_akhir;
	return tTotal;
}

float longitude(float kecepatan,float radius, float waktu_total, float height){
	// Hitung jarak yang dicapai peluru
	// S = V0*t * cos(rad)
	float longitude = kecepatan * waktu_total * cos(radius);
	return longitude;
}

void result(float waktu_total, float height, float longitude){
	printf("\nWaktu yang dibutuhkan untuk mencapai Tanah : %.2f sekon\n",waktu_total);
	printf("\nJarak Peluru :\n");
	printf("Initial Longitude = 0 m\n");
	printf("Initial Latitude = %.0f m\n\n",height);
	printf("Final Longitude = %.0f m\n",longitude);
	printf("Final Latitude = 0 m");
}

int main(){
	
	const float g = 9.8;
	const float phi = 3.14;
	float sudut = 0;
	float rad = 0;
	float wind = 0;
	char direction[20] =""; 
	float v;
	float height = 0;
	float totalHeight = 0;
	// input yaitu kecepatan awal, arah angin serta arah berupa derajat
	printf("================\n");
	printf("KALKULASI PELURU\n");
	printf("================\n\n");
	printf("Masukkan kecepatan peluru (m/s) : ");
	scanf("%f",&v);
	fflush(stdin);

	printf("Masukkan ketinggian (m/s) : ");
	scanf("%f",&height);
	fflush(stdin);

	printf("Masukkan sudut tembak (m/s) : ");
	scanf("%f",&sudut);
	if(sudut==0){
		sudut = 1;
	}
	rad = sudut*phi/180;
	do{
		printf("Masukkan kecepatan dan arah angin [m/s | Barat/Timur/Utara/Selatan] : ");
		scanf("%f %s",&wind, direction);
		fflush(stdin);
	}while(wind>=v || strcmpi(direction,"Barat")!=0 && strcmpi(direction,"Timur")!=0 && strcmpi(direction,"Utara")!=0 && strcmpi(direction,"Selatan")!=0);
	
	if(strcmpi(direction,"Barat")==0 || strcmpi(direction,"Timur")==0){
		v = sqrt(pow(v,2)+pow(wind,2));
	}else if(strcmpi(direction,"Utara")==0){
		v = v+wind;
	}else if(strcmpi(direction,"Selatan")==0){
		v = v-wind;
	}

	waktu_tertinggi(v,rad,g);
	titik_tertinggi(v,rad,g);
	total_Height(height,titik_tertinggi(v,rad,g));
	waktu_jatuh(total_Height(height,titik_tertinggi(v,rad,g)),g);
	waktu_total(waktu_tertinggi(v,rad,g),waktu_jatuh(total_Height(height,titik_tertinggi(v,rad,g)),g));
	longitude(v,rad,waktu_total(waktu_tertinggi(v,rad,g),waktu_jatuh(total_Height(height,titik_tertinggi(v,rad,g)),g)),height);
	result(waktu_total(waktu_tertinggi(v,rad,g),waktu_jatuh(total_Height(height,titik_tertinggi(v,rad,g)),g)),height,longitude(v,rad,waktu_total(waktu_tertinggi(v,rad,g),waktu_jatuh(total_Height(height,titik_tertinggi(v,rad,g)),g)),height));
	getchar();
}