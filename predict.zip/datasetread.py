import pandas as pd
import tensorflow as tf 
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import OrdinalEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split

# def load_dataset(dataset_path, team1,team2):
#     dataset = pd.read_csv(dataset_path)

#     raw_data = dataset[['HomeTeam','AwayTeam','FTHG','FTAG', 'HS','AS', 'FTR']]
    
#     # filtering data by team
#     filtered_team = raw_data[
#                         (raw_data.HomeTeam == team1) | (raw_data.AwayTeam == team1) |
#                         (raw_data.HomeTeam == team2) | (raw_data.AwayTeam == team2)
#                         ] 

#     features = filtered_team[['HomeTeam','AwayTeam','FTHG','FTAG', 'HS','AS']]
#     result = filtered_team[['FTR']]

#     return features, result


# def predict():
#     # INPUT -> HIDDEN
#     Wx1_b = tf.matmul(x,w['hidden']) + b['hidden']
#     y1 = tf.nn.sigmoid(Wx1_b)

#     # HIDDEN -> OUTPUT
#     Wx2_b = tf.matmul(y1, w['output']) + b['output']
#     y2 = tf.nn.sigmoid(Wx2_b)

#     return y2


# MAIN PROGRAGM
def main(argv):
    ########################################
    def load_dataset(dataset_path, team1,team2):
        dataset = pd.read_csv(dataset_path)

        raw_data = dataset[['HomeTeam','AwayTeam','FTHG','FTAG', 'HS','AS', 'FTR']]
        
        # filtering data by team
        filtered_team = raw_data[
                            (raw_data.HomeTeam == team1) | (raw_data.AwayTeam == team1) |
                            (raw_data.HomeTeam == team2) | (raw_data.AwayTeam == team2)
                            ] 

        features = filtered_team[['HomeTeam','AwayTeam','FTHG','FTAG', 'HS','AS']]
        result = filtered_team[['FTR']]

        return features, result


    def predict():
        # INPUT -> HIDDEN
        Wx1_b = tf.matmul(x,w['hidden']) + b['hidden']
        y1 = tf.nn.sigmoid(Wx1_b)

        # HIDDEN -> OUTPUT
        Wx2_b = tf.matmul(y1, w['output']) + b['output']
        y2 = tf.nn.sigmoid(Wx2_b)

        return y2

    ########################################

    team1 = 'Man United'
    team2 = 'Liverpool'

    x_data, y_data = load_dataset('dataset/book.csv', team1, team2)
    print(x_data, "\n", y_data)

    # CONVERT STRING FEATURES TO NUMBER
    ########### x data
    ordinal_encoder = OrdinalEncoder()

    ordinal_encoder = ordinal_encoder.fit(x_data[['HomeTeam','AwayTeam']])

    x_data[['HomeTeam','AwayTeam']] =  ordinal_encoder.transform(x_data[['HomeTeam','AwayTeam']])

    print(x_data)
    ############# y data

    ordinal_encoder = ordinal_encoder.fit(y_data[['FTR']])

    y_data[['FTR']] =  ordinal_encoder.transform(y_data[['FTR']])

    print(y_data)



    #############################################################################
    # ONE HOT ENCODING FOR THE TARGET
    one_hot_encoder = OneHotEncoder(sparse=False)
    one_hot_encoder = one_hot_encoder.fit(y_data)
    y_data = one_hot_encoder.transform(y_data)
    print(y_data)

    # SPLIT DATASET INTO TRAINING & TESTING
    x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.2)

    #NORMALIZE FEATURES
    scaler = MinMaxScaler()
    scaler = scaler.fit(x_train)
    x_train = scaler.transform(x_train)
    x_test = scaler.transform(x_test)

    #CREATE MODEL ARCHITECTURE
    layer = {
        'num_input' : 6,
        'num_hidden' : 4,
        'num_output' : 3
    }

    w = {
        'hidden' : tf.Variable(tf.random_normal([layer['num_input'],layer['num_hidden']])),
        'output' : tf.Variable(tf.random_normal([layer['num_hidden'],layer['num_output']]))
    }

    b = {
        'hidden' : tf.Variable(tf.random_normal([layer['num_hidden']])),
        'output' : tf.Variable(tf.random_normal([layer['num_output']]))
    }

    #CREATE PLACEHOLDER FOR FEEDING DATA
    x = tf.placeholder(tf.float32,[None,layer['num_input']])
    y_true = tf.placeholder(tf.float32,[None, layer['num_output']])
    number_of_epoch = 2000
    y_prediction = predict()

    # LOSS FUNCTION & OPTIMIZER
    loss = tf.reduce_mean(0.5 * (y_true - y_prediction)**2)

    optimizer = tf.train.GradientDescentOptimizer(.1)
    train = optimizer.minimize(loss)

    # TRAINING
    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())

        for i in range(1,number_of_epoch+1):
            sess.run(train,feed_dict={x: x_train, y_true: y_train})
            loss_val = sess.run(loss,feed_dict={x: x_train, y_true : y_train})
            print('Epoch : {}, Loss Val : {}'.format(i,loss_val))
    # TESTING

    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        matches = tf.equal(tf.argmax(y_true,1),tf.argmax(y_prediction,1))

        # [true, false, true] -> [1,0,1] -> 1 + 0 + 1 /3 = 2/3
        accuracy = tf.reduce_mean(tf.cast(matches,tf.float32))

        print('accuracy :', 1-sess.run(accuracy,feed_dict={x:x_test, y_true:y_test}))


if __name__ == '__main__':
    tf.app.run(main=main)
